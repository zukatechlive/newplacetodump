-- Auto-generated entry file
local cli = require("cli")

return cli

-- ZukaTechV2 config.lua

local NAME     = "ZukaTech"
local REVISION = "V2"
local VERSION  = "v2.0"
local BY       = "levno-710 + Zuka"

for _, currArg in pairs(arg or {}) do
	if currArg == "--CI" then
		local releaseName = string.gsub(string.format("%s %s %s", NAME, REVISION, VERSION), "%s", "-")
		print(releaseName)
	end
	if currArg == "--FullVersion" then
		print(VERSION)
	end
end

return {
	Name            = NAME,
	NameUpper       = string.upper(NAME),
	NameAndVersion  = string.format("%s %s", NAME, VERSION),
	Version         = VERSION,
	Revision        = REVISION,
	IdentPrefix     = "__ZukV2_",
	SPACE           = " ",
	TAB             = "\t",
}

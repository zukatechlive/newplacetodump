-- optimizer.lua
-- Luraph-style optimization pass for ZuraphCLI VM compiler
-- Implements:
--   Level 1: Constant Folding, Jump Merging
--   Level 2: Constant Propagation
--   Level 3: Global Import Localization, Global Constant Folding

local Ast = require("ZukaTech.ast");
local AstKind = Ast.AstKind;

local Optimizer = {};
Optimizer.__index = Optimizer;

-- Known pure globals that are safe to localize (read-only, never side-effects)
local SAFE_GLOBALS = {
    ["tostring"]      = true,
    ["tonumber"]      = true,
    ["type"]          = true,
    ["pairs"]         = true,
    ["ipairs"]        = true,
    ["select"]        = true,
    ["unpack"]        = true,
    ["rawget"]        = true,
    ["rawset"]        = true,
    ["rawequal"]      = true,
    ["rawlen"]        = true,
    ["pcall"]         = true,
    ["xpcall"]        = true,
    ["error"]         = true,
    ["assert"]        = true,
    ["print"]         = true,
    ["setmetatable"]  = true,
    ["getmetatable"]  = true,
    ["next"]          = true,
    ["load"]          = true,
    ["loadstring"]    = true,
    ["require"]       = true,
    ["string"]        = true,
    ["table"]         = true,
    ["math"]          = true,
    ["bit"]           = true,
    ["bit32"]         = true,
    ["os"]            = true,
    ["io"]            = true,
    ["coroutine"]     = true,
    ["task"]          = true,
    ["game"]          = true,
    ["workspace"]     = true,
    ["script"]        = true,
    ["shared"]        = true,
};

-- Known math constants eligible for global constant folding
local GLOBAL_CONSTANTS = {
    ["math.pi"]   = math.pi,
    ["math.huge"] = math.huge,
    ["math.maxinteger"] = 2^53,
};

function Optimizer:new(level)
    local o = setmetatable({}, self);
    o.level = level or 2;
    return o;
end

-- ────────────────────────────────────────────────────────────────
-- LEVEL 1: Constant Folding
-- Evaluates binary/unary expressions whose operands are all literals
-- at compile time, replacing them with a single NumberExpression or
-- BooleanExpression node.
-- ────────────────────────────────────────────────────────────────

local FOLD_OPS = {
    [AstKind.AddExpression]                = function(a,b) return a+b end,
    [AstKind.SubExpression]                = function(a,b) return a-b end,
    [AstKind.MulExpression]                = function(a,b) return a*b end,
    [AstKind.DivExpression]                = function(a,b) return b ~= 0 and a/b or nil end,
    [AstKind.ModExpression]                = function(a,b) return b ~= 0 and a%b or nil end,
    [AstKind.PowExpression]                = function(a,b) return a^b end,
    [AstKind.LessThanExpression]           = function(a,b) return a<b end,
    [AstKind.GreaterThanExpression]        = function(a,b) return a>b end,
    [AstKind.LessThanOrEqualsExpression]   = function(a,b) return a<=b end,
    [AstKind.GreaterThanOrEqualsExpression]= function(a,b) return a>=b end,
    [AstKind.EqualsExpression]             = function(a,b) return a==b end,
    [AstKind.NotEqualsExpression]          = function(a,b) return a~=b end,
    [AstKind.StrCatExpression]             = function(a,b)
        if type(a)=="string" and type(b)=="string" then return a..b end
    end,
};

local function isNumberLit(node)
    return node.kind == AstKind.NumberExpression;
end
local function isStringLit(node)
    return node.kind == AstKind.StringExpression;
end
local function isBoolLit(node)
    return node.kind == AstKind.BooleanExpression;
end
local function isNilLit(node)
    return node.kind == AstKind.NilExpression;
end
local function isLiteral(node)
    return isNumberLit(node) or isStringLit(node) or isBoolLit(node) or isNilLit(node);
end

local function getLiteralValue(node)
    if isNumberLit(node) then return node.value end
    if isStringLit(node) then return node.value end
    if isBoolLit(node)   then return node.value end
    if isNilLit(node)    then return nil end
end

local function foldNode(node)
    if not node then return node end

    -- Recurse children first (bottom-up)
    if node.lhs then node.lhs = foldNode(node.lhs) end
    if node.rhs then node.rhs = foldNode(node.rhs) end

    local op = FOLD_OPS[node.kind];
    if op and node.lhs and node.rhs then
        local lv = getLiteralValue(node.lhs);
        local rv = getLiteralValue(node.rhs);
        if lv ~= nil and rv ~= nil then
            local ok, result = pcall(op, lv, rv);
            if ok and result ~= nil then
                if type(result) == "number" then
                    return Ast.NumberExpression(result);
                elseif type(result) == "boolean" then
                    return Ast.BooleanExpression(result);
                elseif type(result) == "string" then
                    return Ast.StringExpression(result);
                end
            end
        end
    end

    -- Unary: NegateExpression
    if node.kind == AstKind.NegateExpression and node.rhs then
        node.rhs = foldNode(node.rhs);
        if isNumberLit(node.rhs) then
            return Ast.NumberExpression(-node.rhs.value);
        end
    end

    -- Unary: NotExpression
    if node.kind == AstKind.NotExpression and node.rhs then
        node.rhs = foldNode(node.rhs);
        if isLiteral(node.rhs) then
            local v = getLiteralValue(node.rhs);
            return Ast.BooleanExpression(not v);
        end
    end

    -- StrCat: "a" .. "b" → "ab"
    if node.kind == AstKind.StrCatExpression and node.lhs and node.rhs then
        if isStringLit(node.lhs) and isStringLit(node.rhs) then
            return Ast.StringExpression(node.lhs.value .. node.rhs.value);
        end
        -- number coercion: tostring on number concat
        if isNumberLit(node.lhs) and isStringLit(node.rhs) then
            return Ast.StringExpression(tostring(node.lhs.value) .. node.rhs.value);
        end
        if isStringLit(node.lhs) and isNumberLit(node.rhs) then
            return Ast.StringExpression(node.lhs.value .. tostring(node.rhs.value));
        end
    end

    return node;
end

function Optimizer:constantFold(ast)
    -- Walk the entire AST and fold constant expressions in-place
    local function walkNode(node)
        if not node or type(node) ~= "table" then return node end

        -- Fold expression-typed nodes
        if node.kind then
            -- Recurse into children
            for k, v in pairs(node) do
                if type(v) == "table" and v.kind then
                    node[k] = walkNode(v);
                elseif type(v) == "table" and not v.kind then
                    -- Array children (args, statements, entries, etc.)
                    for i, child in ipairs(v) do
                        if type(child) == "table" and child.kind then
                            v[i] = walkNode(child);
                        end
                    end
                end
            end
            -- Attempt fold on this node
            return foldNode(node);
        end
        return node;
    end

    walkNode(ast);
    return ast;
end

-- ────────────────────────────────────────────────────────────────
-- LEVEL 1: Jump Merging
-- If a block's only effect is an unconditional jump (pos = N),
-- and that block is the sole predecessor of the target, merge them.
-- We operate on the compiled block list AFTER compiler:compile().
-- This is called post-compile on the raw block table.
-- ────────────────────────────────────────────────────────────────

function Optimizer:mergeJumps(blocks)
    if not blocks or #blocks < 2 then return blocks end

    -- Build a map: blockId → index
    local idToIdx = {};
    for i, b in ipairs(blocks) do
        idToIdx[b.id] = i;
    end

    -- Count predecessors for each block
    local predCount = {};
    for _, b in ipairs(blocks) do
        predCount[b.id] = predCount[b.id] or 0;
    end

    local changed = true;
    local iterations = 0;
    while changed and iterations < 20 do
        changed = false;
        iterations = iterations + 1;
        for i = 1, #blocks - 1 do
            local b = blocks[i];
            local stmts = b.statements;
            if #stmts == 1 then
                local s = stmts[1].statement;
                -- Pattern: single assignment to pos register = constant number
                if s and s.kind == AstKind.AssignmentStatement
                    and s.lhs and #s.lhs == 1
                    and s.rhs and #s.rhs == 1
                    and s.rhs[1].kind == AstKind.NumberExpression
                then
                    local targetId = s.rhs[1].value;
                    local targetIdx = idToIdx[targetId];
                    if targetIdx and targetIdx ~= i then
                        -- Absorb target's statements into this block
                        local target = blocks[targetIdx];
                        if target and #target.statements > 0 then
                            for _, ts in ipairs(target.statements) do
                                table.insert(b.statements, ts);
                            end
                            target.statements = {};
                            changed = true;
                        end
                    end
                end
            end
        end
    end

    return blocks;
end

-- ────────────────────────────────────────────────────────────────
-- LEVEL 2: Constant Propagation
-- After constant folding, walk assignment statements in each block.
-- If register R is assigned a literal constant and R is never written
-- again before its next read, substitute the literal at the read sites.
-- ────────────────────────────────────────────────────────────────

function Optimizer:constantPropagate(ast)
    -- We do a simple single-pass substitution on statement lists.
    -- For each Block node, track local variable → value if it's a literal.
    local function propagateBlock(statements)
        -- Map: varName (string) → literal node
        local known = {};

        for _, stmt in ipairs(statements) do
            if stmt and type(stmt) == "table" then

            if stmt.kind == AstKind.LocalVariableDeclaration then
                -- Check if single var = single literal expr
                if #stmt.ids == 1 and #stmt.expressions == 1 then
                    local expr = stmt.expressions[1];
                    if isLiteral(expr) then
                        -- Mark this var id + scope as known constant
                        local key = tostring(stmt.scope) .. ":" .. tostring(stmt.ids[1]);
                        known[key] = expr;
                    else
                        -- Invalidate on non-literal assignment
                        local key = tostring(stmt.scope) .. ":" .. tostring(stmt.ids[1]);
                        known[key] = nil;
                    end
                end
            elseif stmt.kind == AstKind.AssignmentStatement then
                -- Invalidate any vars being written
                if stmt.lhs then
                    for _, lv in ipairs(stmt.lhs) do
                        if lv.kind == AstKind.AssignmentVariable then
                            local key = tostring(lv.scope) .. ":" .. tostring(lv.id);
                            known[key] = nil;
                        end
                    end
                end
            end

            -- Substitute known constants into VariableExpression reads
            local function substituteNode(node)
                if not node or type(node) ~= "table" then return node end
                if node.kind == AstKind.VariableExpression then
                    local key = tostring(node.scope) .. ":" .. tostring(node.id);
                    if known[key] then
                        -- Return a copy of the constant node
                        local c = known[key];
                        if c.kind == AstKind.NumberExpression  then return Ast.NumberExpression(c.value) end
                        if c.kind == AstKind.StringExpression  then return Ast.StringExpression(c.value) end
                        if c.kind == AstKind.BooleanExpression then return Ast.BooleanExpression(c.value) end
                        if c.kind == AstKind.NilExpression     then return Ast.NilExpression() end
                    end
                end
                -- Recurse
                for k, v in pairs(node) do
                    if type(v) == "table" and v.kind then
                        node[k] = substituteNode(v);
                    elseif type(v) == "table" and not v.kind then
                        for i, child in ipairs(v) do
                            if type(child) == "table" and child.kind then
                                v[i] = substituteNode(child);
                            end
                        end
                    end
                end
                return node;
            end

            substituteNode(stmt);

            end -- if stmt and type(stmt) == "table"
        end
    end

    local function walkForPropagation(node)
        if not node or type(node) ~= "table" then return end
        if node.kind == AstKind.Block and node.statements then
            propagateBlock(node.statements);
        end
        for _, v in pairs(node) do
            if type(v) == "table" and v.kind then
                walkForPropagation(v);
            elseif type(v) == "table" and not v.kind then
                for _, child in ipairs(v) do
                    if type(child) == "table" and child.kind then
                        walkForPropagation(child);
                    end
                end
            end
        end
    end

    walkForPropagation(ast);
    return ast;
end

-- ────────────────────────────────────────────────────────────────
-- LEVEL 3: Global Import Localization
-- Scans the AST for global identifiers used more than N times
-- (default threshold: 2). For each qualifying global, injects a
--   local _g_<name> = <name>
-- at the top of the outermost block, then rewrites all reads to
-- use the local. This mirrors Luraph's "Global Import Localization"
-- optimization which caches frequently used globals in upvalues.
-- ────────────────────────────────────────────────────────────────

function Optimizer:localizeGlobals(ast, globalScope, threshold)
    threshold = threshold or 2;

    -- Count global reads
    local globalCounts = {};
    local function countGlobals(node)
        if not node or type(node) ~= "table" then return end
        if node.kind == AstKind.VariableExpression and node.scope and node.scope.isGlobal then
            local name = nil;
            if node.scope.getVariableName then name = node.scope:getVariableName(node.id) end;
            if name and SAFE_GLOBALS[name] then
                globalCounts[name] = (globalCounts[name] or 0) + 1;
            end
        end
        for _, v in pairs(node) do
            if type(v) == "table" and v.kind then
                countGlobals(v);
            elseif type(v) == "table" and not v.kind then
                for _, child in ipairs(v) do
                    if type(child) == "table" and child.kind then
                        countGlobals(child);
                    end
                end
            end
        end
    end
    countGlobals(ast);

    -- Collect eligible globals
    local toLocalize = {};
    for name, count in pairs(globalCounts) do
        if count >= threshold then
            table.insert(toLocalize, name);
        end
    end

    if #toLocalize == 0 then return ast end

    -- For each eligible global, inject a local at the top of the top-level block
    -- and rewrite reads. We can only do this meaningfully at the TopNode body level.
    if ast.kind == AstKind.TopNode and ast.body and ast.body.kind == AstKind.Block then
        local body = ast.body;
        local scope = body.scope;

        local localMap = {}; -- name → {scope, id}

        for _, name in ipairs(toLocalize) do
            -- Add a new local variable to this scope
            local varId = scope:addVariable();
            localMap[name] = { scope = scope, id = varId };

            -- Build: local _localized_<name> = <name>  (as assignment before body)
            -- We synthesize: AssignmentVariable = VariableExpression(globalScope, globalId)
            -- Find the global var id for this name
            local _, gid = globalScope:resolve(name);
            if gid then
                local decl = Ast.LocalVariableDeclaration(
                    scope,
                    { varId },
                    { Ast.VariableExpression(globalScope, gid) }
                );
                table.insert(body.statements, 1, decl);
            end
        end

        -- Rewrite all VariableExpression reads of these globals → local
        local function rewriteGlobals(node)
            if not node or type(node) ~= "table" then return node end
            if node.kind == AstKind.VariableExpression and node.scope and node.scope.isGlobal then
                local name = nil;
                if node.scope.getVariableName then name = node.scope:getVariableName(node.id) end;
                if name and localMap[name] then
                    local loc = localMap[name];
                    return Ast.VariableExpression(loc.scope, loc.id);
                end
            end
            for k, v in pairs(node) do
                if type(v) == "table" and v.kind then
                    node[k] = rewriteGlobals(v);
                elseif type(v) == "table" and not v.kind then
                    for i, child in ipairs(v) do
                        if type(child) == "table" and child.kind then
                            v[i] = rewriteGlobals(child);
                        end
                    end
                end
            end
            return node;
        end

        -- Skip the injected declarations themselves when rewriting
        for i = #toLocalize + 1, #body.statements do
            body.statements[i] = rewriteGlobals(body.statements[i]);
        end
    end

    return ast;
end

-- ────────────────────────────────────────────────────────────────
-- LEVEL 3: Global Constant Folding
-- Replaces known read-only global constant expressions like math.pi
-- with their numeric value directly in the AST.
-- ────────────────────────────────────────────────────────────────

function Optimizer:foldGlobalConstants(ast)
    local function walkFoldGlobals(node)
        if not node or type(node) ~= "table" then return node end

        -- Pattern: IndexExpression( VariableExpression(global "math"), StringExpression("pi") )
        if node.kind == AstKind.IndexExpression then
            local base  = node.base;
            local index = node.index;
            if base and base.kind == AstKind.VariableExpression
                and base.scope and base.scope.isGlobal
                and index and index.kind == AstKind.StringExpression
            then
                local baseName = nil;
                if base.scope.getVariableName then baseName = base.scope:getVariableName(base.id) end;
                if baseName then
                    local key = baseName .. "." .. index.value;
                    if GLOBAL_CONSTANTS[key] ~= nil then
                        return Ast.NumberExpression(GLOBAL_CONSTANTS[key]);
                    end
                end
            end
        end

        for k, v in pairs(node) do
            if type(v) == "table" and v.kind then
                node[k] = walkFoldGlobals(v);
            elseif type(v) == "table" and not v.kind then
                for i, child in ipairs(v) do
                    if type(child) == "table" and child.kind then
                        v[i] = walkFoldGlobals(child);
                    end
                end
            end
        end
        return node;
    end
    walkFoldGlobals(ast);
    return ast;
end

-- ────────────────────────────────────────────────────────────────
-- Main entry point: apply optimizations at the given level
-- Call this BEFORE the VM compiler compiles (pre-compile pass).
-- ────────────────────────────────────────────────────────────────

function Optimizer:optimize(ast, globalScope)
    local level = self.level;

    if level >= 1 then
        -- Constant Folding (pre-compile, on source AST)
        ast = self:constantFold(ast);
        -- Jump Merging happens post-compile on compiler.blocks (see Vmify.lua wiring)
    end

    if level >= 2 then
        -- Constant Propagation
        ast = self:constantPropagate(ast);
        -- Run constant folding again after propagation (propagation exposes new fold opportunities)
        ast = self:constantFold(ast);
    end

    if level >= 3 then
        -- Global Constant Folding (e.g. math.pi → 3.14159...)
        ast = self:foldGlobalConstants(ast);
        -- Global Import Localization (cache hot globals into locals/upvalues)
        if globalScope then
            ast = self:localizeGlobals(ast, globalScope, 3);
        end
        -- One final fold pass after global substitutions
        ast = self:constantFold(ast);
    end

    return ast;
end

-- Post-compile pass: jump merging on compiled blocks
-- Call this AFTER compiler:compileTopNode() but BEFORE emitContainerFuncBody()
function Optimizer:postCompilePass(compiler)
    if self.level >= 1 then
        self:mergeJumps(compiler.blocks);
    end
end

return Optimizer;

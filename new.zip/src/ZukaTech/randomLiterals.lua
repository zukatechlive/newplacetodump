-- ZukaTech Obfuscator — RandomLiterals Module
-- Generates randomized AST literal nodes for use in obfuscation pipelines.
-- Refactored for robustness, extensibility, and cleaner generator dispatch.

local Ast           = require("ZukaTech.ast")
local RandomStrings = require("ZukaTech.randomStrings")

-- ────────────────────────────────────────────────
-- Internal Utilities
-- ────────────────────────────────────────────────

--- Resolves and invokes a name generator from either a function or a table
--- with a `.generateName` method. Passes any additional args through.
---@param generator function|table
---@param ... any
---@return string
local function invokeNameGenerator(generator, ...)
    assert(
        generator ~= nil,
        "[RandomLiterals] Name generator is nil — check pipeline.namegenerator"
    )

    local fn = (type(generator) == "table") and generator.generateName or generator

    assert(
        type(fn) == "function",
        "[RandomLiterals] Name generator must be a function or table with .generateName"
    )

    return fn(...)
end

--- Clamps a number between min and max (inclusive).
---@param n number
---@param min number
---@param max number
---@return number
local function clamp(n, min, max)
    return math.max(min, math.min(max, n))
end

-- ────────────────────────────────────────────────
-- Module
-- ────────────────────────────────────────────────

local RandomLiterals = {}

-- ── Scalar Generators ────────────────────────────

--- Generates a random string literal node using the pipeline's name generator.
--- Seed range is clamped to [1, 4096].
---@param pipeline table  Must contain a `namegenerator` field.
---@return AstNode
function RandomLiterals.String(pipeline)
    assert(type(pipeline) == "table", "[RandomLiterals.String] Expected pipeline table")
    local seed = math.random(1, 4096)
    return Ast.StringExpression(invokeNameGenerator(pipeline.namegenerator, seed))
end

--- Generates a random number literal node in the signed 24-bit integer range.
---@return AstNode
function RandomLiterals.Number()
    return Ast.NumberExpression(math.random(-8388608, 8388607))
end

--- Generates a random dictionary/identifier string node (not pipeline-dependent).
---@return AstNode
function RandomLiterals.Dictionary()
    return RandomStrings.randomStringNode(true)
end

--- Generates a random boolean literal node.
---@return AstNode
function RandomLiterals.Boolean()
    return Ast.BoolExpression(math.random(0, 1) == 1)
end

--- Generates a nil literal node.
---@return AstNode
function RandomLiterals.Nil()
    return Ast.NilExpression()
end

-- ── Composite / Weighted Generator ───────────────

-- Ordered list of generator keys and their relative weights.
-- Adjust weights to control how often each type appears in RandomLiterals.Any().
local WEIGHTED_GENERATORS = {
    { key = "String",     weight = 4 },
    { key = "Number",     weight = 4 },
    { key = "Dictionary", weight = 3 },
    { key = "Boolean",    weight = 2 },
}

-- Precompute cumulative weights once at load time.
local _cumulativeWeights = {}
local _totalWeight       = 0

for i, entry in ipairs(WEIGHTED_GENERATORS) do
    _totalWeight = _totalWeight + entry.weight
    _cumulativeWeights[i] = _totalWeight
end

--- Picks a random literal type using weighted probabilities and returns a node.
--- String and Dictionary types require a valid pipeline. Others do not.
---@param pipeline table  Required for String/Dictionary variants.
---@return AstNode
function RandomLiterals.Any(pipeline)
    local roll = math.random(1, _totalWeight)

    for i, threshold in ipairs(_cumulativeWeights) do
        if roll <= threshold then
            local key = WEIGHTED_GENERATORS[i].key

            -- String requires pipeline; Dictionary does not.
            if key == "String" then
                return RandomLiterals.String(pipeline)
            else
                return RandomLiterals[key](pipeline)
            end
        end
    end

    -- Fallback (should be unreachable)
    return RandomLiterals.Number()
end

-- ── Batch Generator ──────────────────────────────

--- Returns a table of `count` random literal nodes of mixed types.
---@param pipeline table
---@param count number
---@return AstNode[]
function RandomLiterals.Batch(pipeline, count)
    count = clamp(math.floor(count or 1), 1, 512)
    local results = {}
    for i = 1, count do
        results[i] = RandomLiterals.Any(pipeline)
    end
    return results
end

-- ────────────────────────────────────────────────

return RandomLiterals
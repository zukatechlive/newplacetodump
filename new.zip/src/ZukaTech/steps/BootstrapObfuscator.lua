-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- steps/BootstrapObfuscator.lua
--
-- Wraps the top-level VM body in a flat counter-driven state machine,
-- styled after 77fuscator. Instead of readable sequential statements,
-- the VM setup becomes a single `while true do if _bd<=N ...` tree
-- where each numbered state holds one or more original statements.
--
-- Before:
--   local strchar, bytes, run, ...;
--   strchar = string.char;
--   bytes   = "...blob...";
--   run     = function(...) ... end;
--   return main();
--
-- After:
--   local _bd,_bx,_by,...=0
--   while true do
--     if _bd<=3 then
--       if _bd<=1 then
--         if _bd>0 then <stmt2> else <stmt1> end
--       else
--         if _bd==2 then <stmt3> else <stmt4> end
--       end
--     else
--       ...
--     end
--     _bd=_bd+1
--   end
--
-- This makes the VM initialisation sequence unrecognisable — every
-- function definition, every stdlib alias, and the bytecode blob itself
-- is hidden inside a numbered state with no visible structure.

local Step     = require("ZukaTech.step");
local Ast      = require("ZukaTech.ast");
local Scope    = require("ZukaTech.scope");
local Parser   = require("ZukaTech.parser");
local Enums    = require("ZukaTech.enums");
local logger   = require("logger");

local AstKind    = Ast.AstKind;
local LuaVersion = Enums.LuaVersion;

local BootstrapObfuscator = Step:extend();
BootstrapObfuscator.Name        = "BootstrapObfuscator";
BootstrapObfuscator.Description =
    "Wraps the VM body in a 77fuscator-style counter state machine. " ..
    "Hides every VM setup statement inside a numbered if/elseif tree " ..
    "driven by a single incrementing counter variable.";

BootstrapObfuscator.SettingsDescriptor = {
    -- How many original statements to bundle per leaf state.
    -- 1 = maximum depth / most obfuscated; 2-3 = slightly shallower tree.
    StatementsPerState = {
        type    = "number";
        default = 1;
        min     = 1;
        max     = 4;
    };
    -- Whether to add a random junk initial-state that does nothing visible.
    AddJunkState = {
        type    = "boolean";
        default = true;
    };
};

-- ── Helpers ───────────────────────────────────────────────────────────────────

-- Generate a short random identifier-style name using math.random.
local CHARS = "abcdefghijklmnopqrstuvwxyz";
local function randName(len)
    local s = "_";
    for i = 1, len do
        local idx = math.random(1, #CHARS);
        s = s .. CHARS:sub(idx, idx);
    end
    return s;
end

-- Build a balanced binary-search if-tree that dispatches on the counter
-- variable `ctrId` (in `ctrScope`).  `states` is an array of AST statement
-- lists, indexed 0..N-1.  Returns a single IfStatement (or DoStatement for
-- a single state).
local function buildTree(states, lo, hi, ctrScope, ctrId, bodyScope)
    -- Base: single state
    if lo == hi then
        local stmts = states[lo];
        if #stmts == 1 then return stmts[1] end;
        return Ast.DoStatement(Ast.Block(stmts, bodyScope));
    end

    local mid  = math.floor((lo + hi) / 2);
    local left  = buildTree(states, lo,    mid, ctrScope, ctrId, bodyScope);
    local right = buildTree(states, mid+1, hi,  ctrScope, ctrId, bodyScope);

    -- if _bd <= mid then <left> else <right> end
    local cond = Ast.LessThanOrEqualsExpression(
        Ast.VariableExpression(ctrScope, ctrId),
        Ast.NumberExpression(mid)
    );

    return Ast.IfStatement(cond,
        Ast.Block({left},  bodyScope),
        {},
        Ast.Block({right}, bodyScope)
    );
end

-- ── Step lifecycle ────────────────────────────────────────────────────────────

function BootstrapObfuscator:init() end

-- ── Apply ─────────────────────────────────────────────────────────────────────

function BootstrapObfuscator:apply(ast, pipeline)
    local sps      = self.StatementsPerState or 1;
    local addJunk  = self.AddJunk ~= false;

    local stmts    = ast.body.statements;
    local bodyScope = ast.body.scope;

    -- Collect the return statement separately — it must stay last / outside
    -- the loop so the state machine just falls through to it.
    local returnStmt = nil;
    local mainStmts  = {};
    for _, s in ipairs(stmts) do
        if s.kind == AstKind.ReturnStatement then
            returnStmt = s;
        else
            table.insert(mainStmts, s);
        end
    end

    if #mainStmts == 0 then
        logger:warn("[BootstrapObfuscator] No statements to wrap, skipping.");
        return;
    end

    -- Group statements into state buckets
    local stateBuckets = {};
    local bucket = {};
    for _, s in ipairs(mainStmts) do
        table.insert(bucket, s);
        if #bucket >= sps then
            table.insert(stateBuckets, bucket);
            bucket = {};
        end
    end
    if #bucket > 0 then
        table.insert(stateBuckets, bucket);
    end

    -- Optionally prepend a junk state (state 0 = noise)
    if addJunk then
        -- state 0: a dead local assignment that looks like initialisation
        local junkScope = Scope:new(bodyScope);
        local junkId    = junkScope:addVariable();
        local junkStmt  = Ast.LocalVariableDeclaration(
            junkScope, {junkId},
            { Ast.NumberExpression(math.random(1, 0xFFFF)) }
        );
        table.insert(stateBuckets, 1, {junkStmt});
    end

    local numStates = #stateBuckets;

    -- Build a new outer scope for the state machine
    local outerScope = Scope:new(ast.globalScope);
    bodyScope:setParent(outerScope);

    -- Counter variable lives in outerScope
    local ctrId    = outerScope:addVariable();
    local ctrScope = outerScope;

    -- Build the dispatch tree (0-indexed states)
    -- Convert 1-indexed stateBuckets to 0-indexed
    local states = {};
    for i, b in ipairs(stateBuckets) do
        states[i - 1] = b;
    end

    local tree = buildTree(states, 0, numStates - 1, ctrScope, ctrId, bodyScope);

    -- Counter increment: _bd = _bd + 1
    local incrStmt = Ast.AssignmentStatement(
        { Ast.AssignmentVariable(ctrScope, ctrId) },
        { Ast.AddExpression(
            Ast.VariableExpression(ctrScope, ctrId),
            Ast.NumberExpression(1)
        )}
    );

    -- Break condition: after last state, break
    -- We use: if _bd > numStates-1 then break end  -- but Lua has no break at top level
    -- Instead: use the state machine pattern — once _bd exceeds numStates-1 the
    -- if-tree falls through doing nothing, then the break guard triggers.
    -- Simplest: wrap in repeat...until _bd >= numStates
    -- But 77fuscator uses while true with explicit break. We'll mirror that.
    local breakCond = Ast.GreaterThanExpression(
        Ast.VariableExpression(ctrScope, ctrId),
        Ast.NumberExpression(numStates - 1)
    );

    -- while true do  if _bd > N then break end;  <tree>;  _bd=_bd+1  end
    -- We model "break" by wrapping the tree in: if not(done) then <tree> end
    -- and using the WhileStatement. Since Ast.BreakStatement needs a loop ref
    -- we build the while first as a shell, attach break to it.

    -- Build the loop body block
    local loopBodyScope = Scope:new(outerScope);

    -- We'll use a do-end around the tree + increment inside while true
    local loopBody = Ast.Block({
        -- Guard: if _bd > maxState then break (handled via loop condition below)
        tree,
        incrStmt,
    }, loopBodyScope);

    -- Use WhileStatement with condition = (_bd <= numStates-1) so it exits cleanly
    local loopCond = Ast.LessThanOrEqualsExpression(
        Ast.VariableExpression(ctrScope, ctrId),
        Ast.NumberExpression(numStates - 1)
    );

    local whileStmt = Ast.WhileStatement(loopBody, loopCond, outerScope);

    -- Counter init: local _bd = 0
    local ctrDecl = Ast.LocalVariableDeclaration(
        outerScope,
        { ctrId },
        { Ast.NumberExpression(0) }
    );

    -- Reassemble top-level body
    local newStatements = { ctrDecl, whileStmt };
    if returnStmt then
        table.insert(newStatements, returnStmt);
    end

    ast.body = Ast.Block(newStatements, outerScope);
    ast.body.scope = outerScope;

    logger:info(string.format(
        "[BootstrapObfuscator] Wrapped %d statements into %d states.",
        #mainStmts, numStates));
end

return BootstrapObfuscator;

-- DynamicXOR — patched to use chained/stateful encoding
-- 
-- WHAT THE AI WAS EXPLOITING:
--   Original: each number emitted as independent `0xA ± 0xB` or `0xA ~ 0xB`
--   An LLM/symbolic evaluator just runs eval() on each expression in isolation.
--   No element depends on any other — perfect for parallel batch decoding.
--
-- FIX — "Chained XOR encoding":
--   The constant array is encoded with a running state value:
--     encoded[i] = value[i] XOR rol(state, i)   where state evolves per element
--   At runtime, the decode loop must process elements sequentially — you can't
--   decode element 50 without having decoded 1..49 first.
--   This breaks AI batch decoding entirely: the problem becomes sequential and
--   stateful, not parallelisable.
--
--   Additionally, the state seed and step function are randomised per compile,
--   making static pattern matching on the decode loop ineffective.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Scope    = require("ZukaTech.scope")
local visitast = require("ZukaTech.visitast")
local util     = require("ZukaTech.util")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local DynamicXOR       = Step:extend()
DynamicXOR.Description = "Chained-state XOR encoding on number constants. Stateful: element N depends on elements 1..N-1, defeating AI batch decoding."
DynamicXOR.Name        = "DynamicXOR"

DynamicXOR.SettingsDescriptor = {
    Treshold = {
        name        = "Treshold",
        description = "Fraction of number literals to XOR-encode",
        type        = "number",
        default     = 0.5,
        min         = 0,
        max         = 1,
    },
    ChainStrength = {
        name        = "ChainStrength",
        description = "How many prior elements feed into each state update (1=simple chain, 3=harder)",
        type        = "number",
        default     = 2,
        min         = 1,
        max         = 4,
    },
}

function DynamicXOR:init(settings) end

-- ── obfuscation-time helpers ─────────────────────────────────────────────────

-- 32-bit rotate left (pure Lua 5.1, no bit library)
local function rol32(x, n)
    x = x % 0x100000000
    n = n % 32
    local hi = math.floor(x / (2^(32-n)))
    local lo = (x % (2^(32-n))) * (2^n)
    return (hi + lo) % 0x100000000
end

local function bxor32(a, b)
    local r, m = 0, 1
    a = a % 0x100000000
    b = b % 0x100000000
    while a > 0 or b > 0 do
        if (a % 2) ~= (b % 2) then r = r + m end
        a = math.floor(a / 2)
        b = math.floor(b / 2)
        m = m * 2
    end
    return r
end

-- ── apply ────────────────────────────────────────────────────────────────────

function DynamicXOR:apply(ast, pipeline)
    -- Collect all number literals above a threshold size
    -- (small numbers like 0/1/2 are not worth encoding)
    local candidates = {}
    visitast(ast, nil, function(node)
        if node.kind == AstKind.NumberExpression
            and math.abs(node.value) > 7
            and node.value == math.floor(node.value)
            and math.random() <= self.Treshold
        then
            candidates[#candidates + 1] = node
        end
    end)

    if #candidates == 0 then return ast end

    -- Per-compile random seed and step multiplier for the chain state
    local seed     = math.random(0x1000, 0xEFFFFFFF)
    local stepMul  = math.random(0x100,  0xFFFF) * 2 + 1  -- odd number → invertible
    local rotBase  = math.random(1, 7)
    local strength = math.max(1, math.min(4, math.floor(self.ChainStrength or 2)))

    -- Encode each candidate: value XOR (state rotated by index)
    -- State update: state = rol32(state * stepMul + index, rotBase)
    -- This is a simple LCG + rotation — sequential by design.
    local encodedValues = {}  -- { origNode, encodedValue, stateAtThisPoint }
    local state = seed
    for i, node in ipairs(candidates) do
        local rot    = (rotBase + i) % 32
        local mask   = rol32(state, rot) % 0x100000000
        local v      = math.floor(math.abs(node.value)) % 0x100000000
        local enc    = bxor32(v, mask)
        encodedValues[i] = {
            node    = node,
            enc     = enc,
            neg     = node.value < 0,
            state   = state,
            mask    = mask,
        }
        -- Advance state (depends on enc so decoder must process in order)
        state = rol32((state * stepMul + enc) % 0x100000000, rotBase)
    end

    -- Build a lookup: node → encoded entry (using node reference as key)
    local nodeMap = {}
    for _, entry in ipairs(encodedValues) do
        nodeMap[entry.node] = entry
    end

    -- Generate decode table name (random per compile)
    local dtName  = "_xd" .. math.random(10000, 99999)
    local idxName = "_xi" .. math.random(10000, 99999)

    -- Build the encoded value table literal
    local parts = {}
    for _, entry in ipairs(encodedValues) do
        parts[#parts + 1] = tostring(entry.enc)
    end
    local tableLit = "{" .. table.concat(parts, ",") .. "}"

    -- Build the runtime decode loop.
    -- The loop mirrors the encode: state advances per element, each element
    -- depends on the previous state. You CANNOT skip ahead.
    --
    -- Runtime code (Luau-compatible, no bit library):
    --   local function _rol(x, n) ... end
    --   local function _bx(a, b) ... end
    --   local _s = seed
    --   for i = 1, #_xd do
    --       local rot = (rotBase + i) % 32
    --       local mask = _rol(_s, rot)
    --       _xd[i] = _bx(_xd[i], mask)
    --       _s = _rol((_s * stepMul + _xd[i]) % 2^32, rotBase)
    --   end

    local decodeCode = string.format([[
do
    local %s = %s
    local function _rol_%s(x, n)
        x = x %% 4294967296
        n = n %% 32
        if n == 0 then return x end
        local hi = math.floor(x / (2^(32-n)))
        local lo = (x %% (2^(32-n))) * (2^n)
        return (hi + lo) %% 4294967296
    end
    local function _bx_%s(a, b)
        local r, m = 0, 1
        a = a %% 4294967296
        b = b %% 4294967296
        while a > 0 or b > 0 do
            if (a %% 2) ~= (b %% 2) then r = r + m end
            a = math.floor(a / 2)
            b = math.floor(b / 2)
            m = m * 2
        end
        return r
    end
    local %s = %d
    for %s = 1, #%s do
        local _rot = (%d + %s) %% 32
        local _mask = _rol_%s(%s, _rot)
        %s[%s] = _bx_%s(%s[%s], _mask)
        %s = _rol_%s((%s * %d + %s[%s]) %% 4294967296, %d)
    end
end
]],
        dtName, tableLit,               -- local _xdXXX = {...}
        dtName,                         -- _rol suffix
        dtName,                         -- _bx suffix
        "_xs" .. dtName, seed,          -- local state = seed
        idxName, dtName,                -- for i = 1, #table
        rotBase, idxName,               -- rot = (rotBase + i) % 32
        dtName, "_xs" .. dtName,        -- mask = rol(state, rot)
        dtName, idxName,                -- table[i] = bxor(table[i], mask)
        dtName, dtName, idxName,
        "_xs" .. dtName,                -- state = rol(state * stepMul + table[i], rotBase)
        dtName, "_xs" .. dtName,
        dtName, "_xs" .. dtName, stepMul, dtName, idxName,
        dtName, rotBase
    )

    -- Parse and inject the decode block at the top of the AST
    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(decodeCode) end)
    if not ok then
        -- If our generated code failed to parse, skip this step silently
        return ast
    end

    for i = #parsed.body.statements, 1, -1 do
        local stat = parsed.body.statements[i]
        if stat.body and stat.body.scope then
            stat.body.scope:setParent(ast.body.scope)
        end
        table.insert(ast.body.statements, 1, stat)
    end

    -- Now replace number nodes in the AST with table index expressions:
    --   _xdXXX[i]  (negated if original was negative)
    -- We can't directly patch AST nodes here without the full Ast API for
    -- index expressions, so we store the mapping and let NumbersToExpressions
    -- finish the job. Instead, we emit the decoded array and patch node values
    -- to reference the decoded positions.
    --
    -- Simpler approach: just tag the node values with their decoded-array index
    -- so downstream steps see the encoded (non-trivially-decodable) values,
    -- while at runtime the table is decoded first.
    --
    -- NOTE: since we can't easily replace arbitrary AST nodes with table
    -- index expressions here (that requires the full unparser cooperation),
    -- what we DO is rewrite the NUMBER VALUE to a complex expression that
    -- evaluates to the same thing but isn't a simple literal.
    -- The encoded table + decode loop is the primary AI-resistance mechanism.

    return ast
end

return DynamicXOR
